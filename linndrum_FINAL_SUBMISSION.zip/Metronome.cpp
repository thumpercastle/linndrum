/***** Metronome.cpp *****/

#include <cmath>
#include <Bela.h>
#include "Metronome.h"

// #define LENGTH_OF_TEMPO_CHANGE_COUNTER 5292		// Metronome will wait 12milliseconds before setting new tempo
#define MINIMUM_TEMPO 60

// No args constructor
Metronome::Metronome()
	:
	bpm_ {0},
	beatInterval_ {0},
	sampleRate_ {0},
	beatCounter_ {0},
	beatCounterInterval_ {0},
	metronomeState_ {false},
	metronomeButton_(kMetronomeButtonPin_)
{
}

// Wrapper for all the self-contained functions that need to be called every audio frame
void Metronome::process(BelaContext *context, int n) {
	readTempoPot(context, n/2);
	incrementCounter();
}

// Tell us if the metronome is on(true) or off(false)
bool Metronome::getMetronomeState() {
	return metronomeState_;
}

void Metronome::setSampleRate(int sampleRate) {
	sampleRate_ = sampleRate;
}


// Tempo controls
void Metronome::readTempoPot(BelaContext *context, int n) {
	tempoPotReading_ = analogRead(context, n/2, kTempoPotPin_);
	setTempo((int)map(tempoPotReading_, 0.0, 1, 60, 200));
}

void Metronome::setTempo(int bpm) {
	bpm_ = bpm;
	beatInterval_ = sampleRate_;
	beatCounterInterval_ = (float)bpm_ / MINIMUM_TEMPO;
}


void Metronome::resetCounters() {
	beatCounter_ = 0;
}


int Metronome::getBeatInterval() {
	return beatInterval_;
}

bool Metronome::isDownBeat() {
	if(beatCounter_ == 0) {
		return true;
	}
	else {
		return false;
	}
}



// Increment beatCounter_ and reset it to 0 at the start of each new beat
void Metronome::incrementCounter() {
	beatCounter_ += beatCounterInterval_;
	if(beatCounter_ >= beatInterval_) {
		beatCounter_ = 0;
	}
}

// For debugging
void Metronome::printStatus() {
	rt_printf("bpm_: %d\n", bpm_);
	rt_printf("sampleRate_: %d\n", sampleRate_);
	rt_printf("beatInterval_: %d\n", beatInterval_);
	rt_printf("beatCounter_: %d\n", beatCounter_);
}

// Button handling
bool Metronome::buttonPressed(BelaContext *context, int n) {
	return metronomeButton_.buttonPressed(context, n);
}

// Turn metronome on and off. Scheduler playback follows this in render()
void Metronome::changeMetronomeState() {
	metronomeState_ = !metronomeState_;
}


int Metronome::getBPM() {
	return bpm_;
}

int Metronome::getBeatCounter() {
	return beatCounter_;
}

// Destructor
Metronome::~Metronome() {
	
}
