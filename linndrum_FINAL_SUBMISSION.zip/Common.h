/***** Common.h *****/
// #pragma once

#include "SingleDrum.h"
#include "Scheduler.h"
#include "Button.h"
#include "SingleDrum.h"
#include "Metronome.h"
#include <Bela.h>

// Declare pins
extern int const kMetronomeButtonPin;
extern int const kDrumKitTogglePin;
extern int const kDrum1Pin;
extern int const kDrum2Pin;
extern int const kDrum3Pin;
extern int const kDrum4Pin;
extern int const kRecordingButtonPin;

// Global ints
extern int gDrumKitToggleState;
// extern int gCurrentFrameInBeat;
// extern int gBlockSize;
// extern int gBeatInterval;
// extern bool gTempoChangeOccurred;

// Multimap iterator
// extern std::pair<std::multimap<int, int>::iterator, std::multimap<int, int>::iterator> iterationRange;

// Drum kit toggle button states
enum {
	ToggleState1,
	ToggleState2,
	ToggleState3,
	ToggleState4,
};

/*
*********************************
Functions
*********************************
*/

// Cycle through the four sets of drums and percussion instruments and detect button presses.
void handleDrumKit(BelaContext *context, int n, Button (&DrumButtons)[4], Button (&ToggleButton), SingleDrum (&DrumKit)[16], Scheduler (&oScheduler), Metronome (&gMetronome));
// void recallLoopForCurrentBlock(BelaContext *context, int currentFrameInBeat, SingleDrum (&DrumKit), Scheduler(&gScheduler));
