/***** devnotes.h *****/
/*

03.05 - Global variables and handleDrums() moved into Common.h
03.07 - Use a 3D array to record drum hits instead of BeatClass
03.09 - Implement a multimap structure in Scheduler to hold drum triggers and implement loop recall
04.01 - Working loop function achieved. Not quantised. Not variable length.


2021/04/21
TODO:

2. 
3. Merge metronome and recording buttons and implement countdown.
4. Implement separate playback button.
5. Implement variable loop length

*/