/***** SingleDrum.cpp *****/
#include <Bela.h>
#include <cmath>
#include <vector>
#include "SingleDrum.h"


// No-args Constructor
SingleDrum::SingleDrum()
{
}

// Constructor with 2D vector
SingleDrum::SingleDrum(std::string audioFilename)
{
	assignSample(AudioFileUtilities::load(audioFilename, -1, 0));
}


// Find a read pointer not in use and set it to 0
void SingleDrum::triggerDrum() {
	// Find a read pointer not in use and set it to 0
	for(int i {0}; i < NUMBER_OF_READ_POINTERS_PER_DRUM; i++) {
		if(readPointers_[i] < 0) {
			readPointers_[i] = 0;
			break;
		}
	}
}

// Output the current frame and move read pointer if the read pointer is already in use
float SingleDrum::nextLeftOutput() {
	float leftOut = 0;
	// Find the read pointers which are in use, output the current sample and move them forward one index.
	for(int i {0}; i < NUMBER_OF_READ_POINTERS_PER_DRUM; i++) {
		if(readPointers_[i] >= 0) {
			leftOut += left_[readPointers_[i]];
			readPointers_[i]++;
			if(readPointers_[i] >= left_.size()) {
				readPointers_[i] = -1;
			}
		}
	}
	return leftOut;
}

float SingleDrum::nextRightOutput() {
	float rightOut = 0;
	// Find the read pointers which are in use, output the current sample and move them forward one index.
	for(int i {0}; i < NUMBER_OF_READ_POINTERS_PER_DRUM; i++) {
		if(readPointers_[i] >= 0) {
			rightOut += right_[i] / (NUMBER_OF_READ_POINTERS_PER_DRUM / 2);
			readPointers_[i]++;
			if(readPointers_[i] >= right_.size()) {
				readPointers_[i] = -1;
			}
		}
	}
	return rightOut;
}


void SingleDrum::assignSample(std::vector<std::vector<float> > const& buffer) {
	left_.resize(buffer[0].size());
	right_.resize(buffer[1].size());
	left_.assign(buffer[0].begin(), buffer[0].end());
	right_.assign(buffer[1].begin(), buffer[1].end());
	left_.shrink_to_fit();
	right_.shrink_to_fit();
}
