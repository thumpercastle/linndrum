/***** Scheduler.cpp *****/
#include <Bela.h>
#include "Scheduler.h"


Scheduler::Scheduler()
	:
	loopLengthSamples_{MAX_NUM_BEATS_IN_LOOP * 44100},
	currentBeatInLoop_ {3},
	thirtysecondNoteReadPointer_{-1},
	sixteenthNoteReadPointer_{-1},
	eighthNoteReadPointer_{-1},
	beatInterval_{44100},
	subdivisionToggleState_{eighthNotes_},
	loopCounter_ {0.0},
	loopCounterInterval_ {1.0},
	eighthNoteLoopCounter_ {0.0},
	sixteenthNoteLoopCounter_ {0.0},
	thirtysecondNoteLoopCounter_ {0.0},
	eighthNoteSwingOMeter_ {0.0},
	sixteenthNoteSwingOMeter_ {0.0},
	thirtysecondNoteSwingOMeter_ {0.0},
	swingOMeterBaseReading_ {0.0},
	recordingState_{false},
	playbackState_{false},
	firstRecordingHasStarted_{false},
	loopLengthHasBeenDefined_{false},
	storeDrumEventsInUndoBuffer_{false},
	recordingButton_(kRecordingButtonPin_),
	subdivisionToggle_(kSubdivisionTogglePin_),
	undoButton_(kUndoButtonPin_)
{
}


void Scheduler::setSampleRate(float sampleRate) {
	sampleRate_ = sampleRate;
}


void Scheduler::setTempo(int bpm) {
	bpm_ = bpm;
	loopCounterInterval_ = (float)bpm_ / MINIMUM_TEMPO;
}


int Scheduler::getBPM() {
	return bpm_;
}


int Scheduler::getCurrentBeatNumber() {
	return currentBeatInLoop_;
}


void Scheduler::changePlaybackState() {
	playbackState_ = !playbackState_;
}


void Scheduler::resetCountersToStartOfLoop() {
	currentBeatInLoop_ = 0;
	eighthNoteReadPointer_ = 0;
	sixteenthNoteReadPointer_ = 0;
	thirtysecondNoteReadPointer_ = 0;
	loopCounter_ = 0;
	eighthNoteLoopCounter_ = 0;
	sixteenthNoteLoopCounter_ = 0;
	thirtysecondNoteLoopCounter_ = 0;
}

// Read potentiometer and apply slow down to subdivision counters
void Scheduler::readSwingOMeter(BelaContext *context, int n) {
	swingOMeterBaseReading_ = map(analogRead(context, n/2, kSwingOMeterPotPin_), 0.0, 1.0, 1.0, 0.51);
	
	// Set a threshold for swingOMeter
	if(swingOMeterBaseReading_ >= 0.95) {
		swingOMeterBaseReading_ = 1.0;
	}
	// Apply to 8th notes
	if(subdivisionToggleState_ == eighthNotes_) {
		eighthNoteSwingOMeter_ = swingOMeterBaseReading_;
	}
	// Apply to 16th notes
	else if(subdivisionToggleState_ == sixteenthNotes_) {
		sixteenthNoteSwingOMeter_ = swingOMeterBaseReading_;
	}
	// Apply to 32nd notes
	else if(subdivisionToggleState_ == thirtysecondNotes_) {
		thirtysecondNoteSwingOMeter_ = swingOMeterBaseReading_;
	}
	// Don't apply. Allows reset of pot.
	else if(subdivisionToggleState_ == none_) {
		// Nothing
	}
}


// Compute intervals between onsets, and onset times, fixed to a beat length of 1 second (44100 frames)
void Scheduler::computeStraightBeatSubdivisions() {
	// Check if beatInterval_ is divisible by 8
	// If it is, distribute the frames evenly across 32nd notes
    int remainingFrames = beatInterval_ % 8;
    if(remainingFrames == 0) {
        for(int i  {0}; i < 8; i++) {
            thirtysecondNoteIntervals_[i] = beatInterval_ / 8;
        }
    }
    // If there is a remainder, firstly distribute as evenly possible across 32nd notes
    else {
        for(int i {0}; i < 8; i++) {
            thirtysecondNoteIntervals_[i] = (int)(beatInterval_ / 8);
        }
    }
    // Then distribute the remaining frames across the 32nd notes
    for(int i {0}; remainingFrames != 0; remainingFrames--) {
        thirtysecondNoteIntervals_[i] += 1;
        i++;
        if(remainingFrames <= 0) {
            break;
        }
    }
    for(int i {1}; i < 8; i++) {
        thirtysecondNoteOnsets_[i] = thirtysecondNoteIntervals_[i-1] + thirtysecondNoteOnsets_[i-1];
    }
    // Populate eighthNotes
    eighthNoteOnsets_[0] = 0;
    eighthNoteOnsets_[1] = thirtysecondNoteOnsets_[4];
    eighthNoteIntervals_[0] = eighthNoteOnsets_[1];
    eighthNoteIntervals_[1] = beatInterval_ - eighthNoteOnsets_[1];
    // Populate sixteenthNotes
    for(int i {0}; i < 4; i++) {
    	sixteenthNoteOnsets_[i] = thirtysecondNoteOnsets_[i * 2];
    }
    for(int i {0}; i < 4; i++) {
    	sixteenthNoteIntervals_[i] = thirtysecondNoteIntervals_[i * 2] + thirtysecondNoteIntervals_[(i * 2) + 1];
    }
}


bool Scheduler::hasFirstRecordingTakenPlace() {
	return loopLengthHasBeenDefined_;
}


// Wrapper for other functions to compute note onsets
void Scheduler::computeOnsets() {
	computeStraightBeatSubdivisions();
	// Populate the vector of onset times for the entire loop
	for(int beat {0}; beat < MAX_NUM_BEATS_IN_LOOP; beat++) {
		for(int i {0}; i < 2; i++) {
			allEighthNoteOnsetsInLoop_.push_back((beat * beatInterval_) + eighthNoteOnsets_[i]);
		}
		for(int i {0}; i < 4; i++) {
			allSixteenthNoteOnsetsInLoop_.push_back((beat * beatInterval_) + sixteenthNoteOnsets_[i]);
		}
		for(int i {0}; i < 8; i++) {
			allThirtysecondNoteOnsetsInLoop_.push_back((beat * beatInterval_) + thirtysecondNoteOnsets_[i]);
		}
	}
	// Sort the onsets into chronological order
	// eighthNoteOnsets_
	sort(allEighthNoteOnsetsInLoop_.begin(), allEighthNoteOnsetsInLoop_.end());
	allEighthNoteOnsetsInLoop_.erase(unique(allEighthNoteOnsetsInLoop_.begin(), allEighthNoteOnsetsInLoop_.end()),
		allEighthNoteOnsetsInLoop_.end());
	// sixteenthNoteOnsets_
	sort(allSixteenthNoteOnsetsInLoop_.begin(), allSixteenthNoteOnsetsInLoop_.end());
	allSixteenthNoteOnsetsInLoop_.erase(unique(allSixteenthNoteOnsetsInLoop_.begin(), allSixteenthNoteOnsetsInLoop_.end()),
		allSixteenthNoteOnsetsInLoop_.end());
	// thirtysecondNoteOnsets_
	sort(allThirtysecondNoteOnsetsInLoop_.begin(), allThirtysecondNoteOnsetsInLoop_.end());
	allThirtysecondNoteOnsetsInLoop_.erase(unique(allThirtysecondNoteOnsetsInLoop_.begin(), allThirtysecondNoteOnsetsInLoop_.end()),
		allThirtysecondNoteOnsetsInLoop_.end());
}


int Scheduler::quantiseOnset(int triggerFrame) {
	// Where in the loop does our drum event occur?
	triggerFrame += (currentBeatInLoop_ * beatInterval_);
	// Initialise a pointer to the appropriate array of onset times, given quantisationState_
	int* subdivisionOnsetsPtr = nullptr;
	int numberOfSubdivisionOnsets = 0;
	switch(subdivisionToggleState_) {
		case eighthNotes_:
			subdivisionOnsetsPtr = eighthNoteOnsets_;
			numberOfSubdivisionOnsets = 2;
			break;
		case sixteenthNotes_:
			subdivisionOnsetsPtr = sixteenthNoteOnsets_;
			numberOfSubdivisionOnsets = 4;
			break;
		case thirtysecondNotes_:
			subdivisionOnsetsPtr = thirtysecondNoteOnsets_;
			numberOfSubdivisionOnsets = 8;
			break;
		case none_:
			subdivisionOnsetsPtr = thirtysecondNoteOnsets_;
			numberOfSubdivisionOnsets = 8;
			break;
	}
	// Initialise an integer to hold the onset time to be returned
	int quantisedDrumOnset = -1;
	// Iterate through pairs of subdivision onsets and find out between which onsets the trigger occured
	int startOfBeat {currentBeatInLoop_ * beatInterval_};
	int nextOnset {0};
	int previousOnset {0};
	int differenceAbove {0};
	int differenceBelow {0};
	
	for(int i {0}; i < numberOfSubdivisionOnsets; i++) {
		// If we triggered the drum between last onset and first of a new beat, wrap it around
		if(i == numberOfSubdivisionOnsets - 1) {
			nextOnset = 0 + startOfBeat + beatInterval_;	// The starting frame of the next beat
			if(nextOnset >= loopLengthSamples_) {					// Wrap it round if we have reached the end of the loop
				nextOnset = loopLengthSamples_;
			}
		}
		// If we triggered the drum at any other point in the beat
		else {
			nextOnset = *(subdivisionOnsetsPtr + i + 1) + startOfBeat;
		}

		previousOnset = *(subdivisionOnsetsPtr + i) + startOfBeat;

		// If the triggerFrame didn't occur between this pair of onsets, move on		
		if(triggerFrame >= nextOnset) {
			continue;
		}
		// Otherwise, compute the distance to the next and previous onsets
		else {
			differenceAbove = nextOnset - triggerFrame;
			differenceBelow = triggerFrame - previousOnset;
			break;
		}
	}
	
	// If the next onset is closest
	if(differenceAbove < differenceBelow) {
		// If the trigger occured a the end of a beat, wrap it
		if(nextOnset >= loopLengthSamples_) {					// Wrap it round if we have reached the end of the loop
			nextOnset = 0;
		}
		// Otherwise, define the quantisedDrumOnset as the next onset
		quantisedDrumOnset = nextOnset;
	}
	
	// If the previous onset it closest
	else {
		quantisedDrumOnset = previousOnset;
	}
	
	return quantisedDrumOnset;
}


void Scheduler::readRecordingButton(BelaContext *context, int n) {
	if(recordingButton_.buttonPressed(context, n) == true) {
		// First button press in a brand new loop
		if(firstRecordingHasStarted_ == false) {
			currentBeatInLoop_ = -1;
			beatToQuantiseTo_ = -1;
			firstRecordingHasStarted_ = true;
			recordingState_ = true;
		}
		// Second button press in a brand new loop (ends loop and defines its length)
		else if(firstRecordingHasStarted_ == true && loopLengthHasBeenDefined_ == false) {
			numBeatsInLoop_ = currentBeatInLoop_ + 1;
			loopLengthSamples_ = numBeatsInLoop_ * beatInterval_;
			loopLengthHasBeenDefined_ = true;
			recordingState_ = false;
			playbackState_ = true;
		}
		// All subsequent button presses
		else if(loopLengthHasBeenDefined_ == true) {
			rt_printf("undo buffer size: %d\n", undoBuffer_.size());
			recordingState_ = !recordingState_;
			
			// If we are starting a new layer of the recording, clear the undoBuffer_
			if(recordingState_) {
				undoBuffer_.clear();
				rt_printf("undo buffer size: %d\n", undoBuffer_.size());
			}
			rt_printf("recording state: %d\n", recordingState_);
		}
	}
}


void Scheduler::readSubdivisionToggle(BelaContext * context, int n) {
	if(subdivisionToggle_.buttonPressed(context, n)) {
		subdivisionToggleState_++;
		rt_printf("subdivision toggle pressed. State: %d\n", subdivisionToggleState_);
		if(subdivisionToggleState_ > none_) {
			subdivisionToggleState_ = eighthNotes_;
		}
	}
}


void Scheduler::countBeat() {
	// Increment beat counter and wrap it if necessary
	if(++currentBeatInLoop_ >= numBeatsInLoop_) {
		resetCountersToStartOfLoop();
	}
	// If beatToQuantiseTo has not been pushed forward by the quantisation function, increment now to follow the beat.
	if(beatToQuantiseTo_ != currentBeatInLoop_) {
		beatToQuantiseTo_ = currentBeatInLoop_;
	}
}


bool Scheduler::getRecordingState() {
	return recordingState_;
}


bool Scheduler::getPlaybackState() {
	return playbackState_;
}


void Scheduler::setDrumkit(SingleDrum gDrumkit[16]) {
	drumkit_ = gDrumkit;
}


// Store current frame and drum index into the drumWriteBuffer_ awaiting long term storage.
// Drum events in the drumWriteBuffer_ are not recalled for playback, this is to prevent
// slapback effect where the event is quantised forward and immediately recalled.
void Scheduler::writeDrumEventToBuffer(int quantisedFrame, int drumIdx) {
	drumWriteBuffer_.push_back(std::vector<int> {quantisedFrame, drumIdx, subdivisionToggleState_});
}


void Scheduler::writeDrumEventToUndoBuffer(int quantisedFrame, int drumIdx) {
	undoBuffer_.push_back(std::vector<int> {quantisedFrame, drumIdx, subdivisionToggleState_});
}


void Scheduler::readUndoButton(BelaContext *context, int n) {
	if(undoButton_.buttonPressed(context, n)) {
		undoButtonHasBeenPressed_ = true;
	}
}


void Scheduler::undoLastRecording() {
	if(undoButtonHasBeenPressed_) {
		if(undoBuffer_.size() > 0) {
			for(int i {0}; i < undoBuffer_.size(); i++) {
				// If the drum event in question is an eighthNote
				if(undoBuffer_[i][2] == eighthNotes_) {
					// Iterate through the multimap and find matching keys
					ummIteratorRange_ = eighthNoteLoopMap_.equal_range(undoBuffer_[i][0]);
					for(auto it = ummIteratorRange_.first; it != ummIteratorRange_.second; ) {
						// If the drum index of the query and recording match, erase the drum event
						if(it->second == undoBuffer_[i][1]) {
							it = eighthNoteLoopMap_.erase(it);
						}
						else {
							++it;
						}
					}
				}
				// If the event is a sixteenthNote
				else if(undoBuffer_[i][2] == sixteenthNotes_) {
					// Iterate through the multimap and find matching keys
					ummIteratorRange_ = sixteenthNoteLoopMap_.equal_range(undoBuffer_[i][0]);
					for(auto it = ummIteratorRange_.first; it != ummIteratorRange_.second; ) {
						// If the drum index of the query and recording match, erase the drum event
						if(it->second == undoBuffer_[i][1]) {
							it = sixteenthNoteLoopMap_.erase(it);
						}
						else {
							++it;
						}
					}
				}
				// If the event is a thirtysecondNote
				else if(undoBuffer_[i][2] == thirtysecondNotes_ || undoBuffer_[i][2] == none_) {
					// Iterate through the multimap and find matching keys
					ummIteratorRange_ = thirtysecondNoteLoopMap_.equal_range(undoBuffer_[i][0]);
					for(auto it = ummIteratorRange_.first; it != ummIteratorRange_.second; ) {
						// If the drum index of the query and recording match, erase the drum event
						if(it->second == undoBuffer_[i][1]) {
							it = thirtysecondNoteLoopMap_.erase(it);
						}
						else {
							++it;
						}
					}
				}
			}
		}
		undoButtonHasBeenPressed_ = false;
	}
}




void Scheduler::processDrumWriteBuffer() {
	// If drumWriteBuffer_ is not empty
	if(drumWriteBuffer_.size() != 0) {
		// Iterate through it
		for(int i {0}; i < drumWriteBuffer_.size(); i++) {
			// Check if the loopCounter has gone past the event trigger time
			if(drumWriteBuffer_[i][0] < loopCounter_) {
				// And assign to the appropriate loop map
				// eighthNotes_
				if(drumWriteBuffer_[i][2] == eighthNotes_) {
					eighthNoteLoopMap_.insert( {drumWriteBuffer_[i][0], drumWriteBuffer_[i][1]});
					drumWriteBuffer_.erase(drumWriteBuffer_.begin() + i);
				}
				// sixteenthNotes_
				else if(drumWriteBuffer_[i][2] == sixteenthNotes_) {
					sixteenthNoteLoopMap_.insert( {drumWriteBuffer_[i][0], drumWriteBuffer_[i][1]});
					drumWriteBuffer_.erase(drumWriteBuffer_.begin() + i);
				}
				// thirtysecondNotes_
				else if(drumWriteBuffer_[i][2] == thirtysecondNotes_ || drumWriteBuffer_[i][2] == none_) {
					thirtysecondNoteLoopMap_.insert( {drumWriteBuffer_[i][0], drumWriteBuffer_[i][1]});
					drumWriteBuffer_.erase(drumWriteBuffer_.begin() + i);
				}
			}
		}
	}
}


void Scheduler::applySwingToLoopCounters() {
	// Apply swing to only the odd-numbered note onsets
	// eighthNotes_
	if(eighthNoteReadPointer_ == 0 || eighthNoteReadPointer_ % 2 == 0) {
		eighthNoteLoopCounter_ = loopCounter_;
	}
	else {
		eighthNoteLoopCounter_ = allEighthNoteOnsetsInLoop_[eighthNoteReadPointer_ - 1] +
			(loopCounter_ - allEighthNoteOnsetsInLoop_[eighthNoteReadPointer_ - 1]) * eighthNoteSwingOMeter_;
	}
	// sixteenthNotes_
	if(sixteenthNoteReadPointer_ == 0 || sixteenthNoteReadPointer_ % 2 == 0) {
		sixteenthNoteLoopCounter_ = loopCounter_;
	}
	else {
		sixteenthNoteLoopCounter_ = allSixteenthNoteOnsetsInLoop_[sixteenthNoteReadPointer_ - 1] +
			(loopCounter_ - allSixteenthNoteOnsetsInLoop_[sixteenthNoteReadPointer_ - 1]) * sixteenthNoteSwingOMeter_;
	}
	// thirtysecondNotes_
	if(thirtysecondNoteReadPointer_ == 0 || thirtysecondNoteReadPointer_ % 2 == 0) {
		thirtysecondNoteLoopCounter_ = loopCounter_;
	}
	else {
		thirtysecondNoteLoopCounter_ = allThirtysecondNoteOnsetsInLoop_[thirtysecondNoteReadPointer_ - 1] +
			(loopCounter_ - allThirtysecondNoteOnsetsInLoop_[thirtysecondNoteReadPointer_ - 1]) * thirtysecondNoteSwingOMeter_;
	}
}



// Increment counters and recall drum events if the counter passes the onset indicated by the read pointer
void Scheduler::timeKeepingAndLoopRecall(float beatCounter) {
	// beatCounter is the current counter position within an individual beat, passed by Metronome
	// loopCounter_ indicates where in the loop we are
	loopCounter_ = (currentBeatInLoop_ * sampleRate_) + beatCounter;
	// Apply swing
	applySwingToLoopCounters();
	// If the loop counters for each onset have passed an onset indicated by their read pointers, trigger that event
	// eighthNotes_
	if(eighthNoteLoopCounter_ >= allEighthNoteOnsetsInLoop_[eighthNoteReadPointer_] &&
			eighthNoteReadPointer_ <= (numBeatsInLoop_ * 2) - 1) {
		triggerOnset(eighthNotes_);
		eighthNoteReadPointer_++;
	}
	// sixteenthNotes_
	if(sixteenthNoteLoopCounter_ >= allSixteenthNoteOnsetsInLoop_[sixteenthNoteReadPointer_] &&
			sixteenthNoteReadPointer_ <= (numBeatsInLoop_ * 4) - 1) {
		triggerOnset(sixteenthNotes_);
		sixteenthNoteReadPointer_++;
	}
	// thirtysecondNotes_
	if(thirtysecondNoteLoopCounter_ >= allThirtysecondNoteOnsetsInLoop_[thirtysecondNoteReadPointer_] &&
			thirtysecondNoteReadPointer_ <= (numBeatsInLoop_ * 8) - 1) {
		triggerOnset(thirtysecondNotes_);
		thirtysecondNoteReadPointer_++;
	}
}


// Trigger drum events
void Scheduler::triggerOnset(int subdivision) {
	// subdivision is eighthNotes_, sixteenthNotes_, thirtysecondNotes_, passed by timeKeepingAndLoopRecall()
	// This function triggers the next drum event indicated by the read pointer for each individual subdivision
	
	// If playback is activated
	if(playbackState_ == true) {
		// triggerFrame is the onset time to search the map for
		int triggerFrame = 0;
		// If we are being asked to trigger eighthNotes_
		if(subdivision == eighthNotes_) {
			triggerFrame = allEighthNoteOnsetsInLoop_[eighthNoteReadPointer_];
			// If a drum event exists in the map for this onset
			if(eighthNoteLoopMap_.count(triggerFrame) != 0) {
				// Iterate through all drums at this onset and trigger them
				ummIteratorRange_ = eighthNoteLoopMap_.equal_range(triggerFrame);
				for(auto it = ummIteratorRange_.first; it != ummIteratorRange_.second; it++) {
					(*(drumkit_ + it->second)).triggerDrum();
				}
			}
		}
		// Repeat for sixteenthNotes_
		if(subdivision == sixteenthNotes_) {
			triggerFrame = allSixteenthNoteOnsetsInLoop_[sixteenthNoteReadPointer_];
			if(sixteenthNoteLoopMap_.count(triggerFrame) != 0) {
				ummIteratorRange_ = sixteenthNoteLoopMap_.equal_range(triggerFrame);
				for(auto it = ummIteratorRange_.first; it != ummIteratorRange_.second; it++) {
					(*(drumkit_ + it->second)).triggerDrum();
				}
			}
		}
		// Repeat for thirtysecondNotes_
		if(subdivision == thirtysecondNotes_) {
			triggerFrame = allThirtysecondNoteOnsetsInLoop_[thirtysecondNoteReadPointer_];
			if(thirtysecondNoteLoopMap_.count(triggerFrame) != 0) {
				ummIteratorRange_ = thirtysecondNoteLoopMap_.equal_range(triggerFrame);
				for(auto it = ummIteratorRange_.first; it != ummIteratorRange_.second; it++) {
					(*(drumkit_ + it->second)).triggerDrum();
				}
			}
		}
	}
}


// Destructor
Scheduler::~Scheduler() {
}