#include <Bela.h>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include "SingleDrum.h"
#include "Scheduler.h"
#include "Button.h"
#include "SingleDrum.h"
#include "Common.h"
#include "Metronome.h"

// Defined constants
#define NUMBER_OF_DRUMS 16
#define NUMBER_OF_DRUMS_PER_TOGGLE 4
#define MAX_NUM_DRUM_HITS_PER_BEAT 48
#define MAX_NUM_NOTES_IN_LOOP 768


/**********************************
 * Initialise globals			  *
 * *******************************/

// Initialise button pins - declared in Common.h
const int kMetronomeButtonPin {0};
const int kDrumKitTogglePin {1};
const int kDrum1Pin {2};
const int kDrum2Pin {3};
const int kDrum3Pin {4};
const int kDrum4Pin {5};
const int kRecordingButtonPin {8};

// Initialise external globals - declared in Common.h
// Toggle between 4 sets of drum and percussion sounds
int gDrumKitToggleState {ToggleState1};

// *****************************************
// Initialise objects
// *****************************************

// Initialise Metronome
Metronome gMetronome;

// Initialise Scheduler
Scheduler gScheduler;

// Initialise buttons
Button gDrumKitToggleButton(kDrumKitTogglePin);
Button oDrumButton1(kDrum1Pin);
Button oDrumButton2(kDrum2Pin);
Button oDrumButton3(kDrum3Pin);
Button oDrumButton4(kDrum4Pin);

// Initialise an array to hold all Drum Button objects
Button gDrumButtons[4] {oDrumButton1, oDrumButton2, oDrumButton3, oDrumButton4};

// Declare an array to hold all SingleDrum objects
SingleDrum gDrumKit[16];


bool setup(BelaContext *context, void *userData)
{
	// Initialise metronome
	gMetronome.setSampleRate(context->audioSampleRate);
	gMetronome.setTempo(60);
	
	// Initialise Scheduler
	gScheduler.setTempo(gMetronome.getBPM());
	gScheduler.setSampleRate(context->audioSampleRate);
	gScheduler.computeOnsets();

	// Initialise drum objects
	SingleDrum oCabasa("cabasa_01_t1.wav");
	SingleDrum oHihatClosedA("cl-hat_01_t1.wav");
	SingleDrum oHihatClosedB("cl-hat_03_t1.wav");
	SingleDrum oHihatOpen("op-hat_01_t1.wav");
	SingleDrum oClap("clap_01_t1.wav");
	SingleDrum oCowbell("cowbell_01_t1.wav");
	SingleDrum oCrash("crash_01_t1.wav");
	SingleDrum oKickA("kick_01_t1.wav");
	SingleDrum oKickB("kick_08_t1.wav");
	SingleDrum oRide("ride_01_t1.wav");
	SingleDrum oRim("rim_01_t1.wav");
	SingleDrum oSnareA("snare_01_t1.wav");
	SingleDrum oSnareB("snare_04_t1.wav");
	SingleDrum oTomA("tom_01_t1.wav");
	SingleDrum oTomB("tom_02_t1.wav");
	SingleDrum oTomC("tom_03_t1.wav");
	
	gDrumKit[0] = oKickA;
	gDrumKit[1] = oKickB;
	gDrumKit[2] = oSnareA;
	gDrumKit[3] = oSnareB;
	gDrumKit[4] = oHihatClosedA;
	gDrumKit[5] = oHihatClosedB;
	gDrumKit[6] = oHihatOpen;
	gDrumKit[7] = oCrash;
	gDrumKit[8] = oCowbell;
	gDrumKit[9] = oRide;
	gDrumKit[10] = oRim;
	gDrumKit[11] = oClap;
	gDrumKit[12] = oCabasa;
	gDrumKit[13] = oTomA;
	gDrumKit[14] = oTomB;
	gDrumKit[15] = oTomC;
	
	gScheduler.setDrumkit(gDrumKit);
	
	return true;
}


void render(BelaContext *context, void *userData)
{
	// Move drums from buffer into the loop store if enough time has elapsed
	gScheduler.processDrumWriteBuffer();
	// If the undo button was pressed during the last block, erase recording from loop
	gScheduler.undoLastRecording();

	// Begin a new block
	for(unsigned int n = 0; n < context->audioFrames; n++) {
		float out = 0;

		// If there has been a tempo change, update the Scheduler.
		if(gScheduler.getBPM() != gMetronome.getBPM()) {
			gScheduler.setTempo(gMetronome.getBPM());
			rt_printf("tempo change %d BPM\n", gMetronome.getBPM());
		}

		// Read buttons
		gScheduler.readRecordingButton(context, n);
		gScheduler.readSubdivisionToggle(context, n);
		gScheduler.readUndoButton(context, n);
		gScheduler.readSwingOMeter(context, n);
		
		// Read metronome button and turn on/off
		if(gMetronome.buttonPressed(context, n)) {
			gMetronome.changeMetronomeState();
			// Reset counters
			gMetronome.resetCounters();
			gScheduler.resetCountersToStartOfLoop();
		}
		
		// If the metronome is on, play the loop
		if(gMetronome.getMetronomeState() == true) {
			// Increment counters
			gMetronome.process(context, n);
			// Play increment counters, read pointers and play loop
			gScheduler.timeKeepingAndLoopRecall(gMetronome.getBeatCounter());
			// Check for start of new beat, and tell Scheduler if so.
			if(gMetronome.isDownBeat()) {
				gScheduler.countBeat();
				rt_printf("current beat in loop: %d\n", gScheduler.getCurrentBeatNumber());
				// Add a click to the output only the first time round the loop
				if(gScheduler.hasFirstRecordingTakenPlace() == false) {
					out += 0.5;
				}
			}
		}

		// Iterate over the drum buttons and detect button presses.
		// Pass drum event to Scheduler for storage
		handleDrumKit(context, n, gDrumButtons, gDrumKitToggleButton, gDrumKit, gScheduler, gMetronome);

		// Loop through all drums and advance the read pointers, assign to output.
		for(int i {0}; i < NUMBER_OF_DRUMS; i++) {
			out += gDrumKit[i].nextLeftOutput() / NUMBER_OF_DRUMS;
		}
		
		// Write the sample to every channel
		for(unsigned int channel = 0; channel < context->audioOutChannels; channel++) {
			audioWrite(context, n, channel, out);
		}
	}
}

void cleanup(BelaContext *context, void *userData)
{

}