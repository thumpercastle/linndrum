/***** Scheduler.h *****/
#pragma once

#include <cmath>
#include <unordered_map>
#include <list>
#include <algorithm>
#include <Bela.h>
#include "Button.h"
#include "SingleDrum.h"
#include "Metronome.h"


// Defined constants
#define NUMBER_OF_DRUMS 16
#define NUMBER_OF_DRUMS_PER_TOGGLE 4
#define MAX_NUM_BEATS_IN_LOOP 16
#define MAX_NUM_DRUM_HITS_PER_BEAT 48
#define MAX_NUM_NOTES_IN_LOOP 768
#define DRUM_STORE_WAIT_TIME 44100			// Wait 0.5 seconds before storing a drum hit

class Scheduler
{
private:
	// Pins for hardware
	const int kSwingOMeterPotPin_ {1};
	const int kRecordingButtonPin_ {8};
	const int kSubdivisionTogglePin_ {9};
	const int kUndoButtonPin_{12};
	
	// Total number of audio frames in the loop
	int loopLengthSamples_;
	
	// Which beat are we currently on in the loop?
	int currentBeatInLoop_;
	
	// Follow the beat numbers in the loop and tell quantisation function which beat to align to.
	// It is pushed to next beat if a drum is triggered just before the beat
	int beatToQuantiseTo_;
	
	// Total number of beats in the loop. Starts at 16 and is defined by the length of the first recording.
	int numBeatsInLoop_ {MAX_NUM_BEATS_IN_LOOP};
	
	// Read pointers
	int thirtysecondNoteReadPointer_;			
	int sixteenthNoteReadPointer_;
	int eighthNoteReadPointer_;
	
	// Tempo in BPM
	int bpm_;
	int beatInterval_;	
	
	// Number of audio frames between beats (fixed at 44100)
	// Onset interval lengths, and onset times
	int eighthNoteIntervals_[2];
	int eighthNoteOnsets_[2];
	int sixteenthNoteIntervals_[4];
	int sixteenthNoteOnsets_[4];
	int thirtysecondNoteIntervals_[8];
	int thirtysecondNoteOnsets_[8];
	int subdivisionToggleState_;
	
	// Total length of the loop in audio frames
	float loopCounter_;
	
	// Sample rate
	float sampleRate_;
	
	// Amount to be added to counters as each frame passes
	float loopCounterInterval_;					
	float eighthNoteLoopCounter_;
	float sixteenthNoteLoopCounter_;
	float thirtysecondNoteLoopCounter_;
	
	// Percentage reduction in loop counter intervals, given level of swing
	float eighthNoteSwingOMeter_;
	float sixteenthNoteSwingOMeter_;
	float thirtysecondNoteSwingOMeter_;
	float swingOMeterBaseReading_;
	
	// Which subdivision are we swinging or quantising to?
	enum {
		eighthNotes_,
		sixteenthNotes_,
		thirtysecondNotes_,
		none_,					// Quantises to 32nd notes, swings none (allows reset of pot)
	};
	
	// Onset times
	std::vector<int> allThirtysecondNoteOnsetsInLoop_;
	std::vector<int> allSixteenthNoteOnsetsInLoop_;
	std::vector<int> allEighthNoteOnsetsInLoop_;
	
	// A buffer holding trigger times and drum indices awaiting storage
	std::vector<std::vector<int> > drumWriteBuffer_;
	
	// Store the last layer added to loop to allow for undo
	std::vector<std::vector<int> > undoBuffer_;

	// Pointer to the first element of the global array of SingleDrum objects
	SingleDrum *drumkit_;
	
	// Are we recording?
	bool recordingState_;
	bool playbackState_;
	bool firstRecordingHasStarted_;
	bool loopLengthHasBeenDefined_;
	bool storeDrumEventsInUndoBuffer_;
	bool undoButtonHasBeenPressed_;
	
	// Hold key : value pairs of frame : drum index
	std::unordered_multimap<int, int> eighthNoteLoopMap_;
	std::unordered_multimap<int, int> sixteenthNoteLoopMap_;
	std::unordered_multimap<int, int> thirtysecondNoteLoopMap_;
	
	// Pair of iterators for traversing the unordered_multimaps
	std::pair<std::unordered_multimap<int, int>::iterator, std::unordered_multimap<int, int>::iterator> ummIteratorRange_;

	// Buttons
	Button recordingButton_;
	Button subdivisionToggle_;
	Button undoButton_;
	
public:
	// Constructor
	Scheduler();

	// Setter and timekeeping functions
	void setSampleRate(float);
	void setTempo(int);
	void setDrumkit(SingleDrum gDrumkit[]);
	void setLoopCounter(float);

	// Getter functions	
	bool getRecordingState();
	bool getPlaybackState();
	bool hasFirstRecordingTakenPlace();
	int getCurrentBeatNumber();
	int getCurrentFrameInLoop();
	int getBPM();

	// Quantisation functions
	void computeOnsets();								// Compute all onsets for max loop length
	void computeStraightBeatSubdivisions();				// Compute onsets and intervals for an individual beat
	int quantiseOnset(int);								// Quantise an onset to the nearest subdivision
	
	// Counter functions
	void timeKeepingAndLoopRecall(float beatCounter);
	void countBeat();
	void applySwingToLoopCounters();
	void resetCountersToStartOfLoop();
	
	// Button
	void readRecordingButton(BelaContext *context, int);
	void readSwingOMeter(BelaContext *context, int);
	void readSubdivisionToggle(BelaContext *context, int);
	
	// Store and read loop
	void writeDrumEventToBuffer(int, int);
	void writeDrumEventToUndoBuffer(int, int);
	void undoLastRecording();
	void processDrumWriteBuffer();
	void triggerOnset(int);
	void changePlaybackState();
	void readUndoButton(BelaContext *context, int n);

	// Destructor
	~Scheduler();
};