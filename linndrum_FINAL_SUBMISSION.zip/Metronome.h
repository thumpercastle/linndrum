/***** Metronome.h *****/
#pragma once

#include <cmath>
#include <Bela.h>
#include "Button.h"

#define MINIMUM_TEMPO 60
#define MAXIMUM_TEMPO 200


class Metronome
{
private:
	const int kTempoPotPin_ = 0;
	const int kMetronomeButtonPin_ = 0;
	int metronomeButtonLastStatus_;
	int metronomeButtonStatus_;
	int bpm_;
	int beatInterval_;										// Number of audioFrames per beat
	float tempoPotReading_;
	float lastTempoPotReading_;
	float sampleRate_;
	float beatCounter_;										// Counting audioFrames between each beat
	float beatCounterInterval_;
	bool metronomeState_;
	Button metronomeButton_;
	
public:
	// Constructor
	Metronome();
	
	// Member functions
	void process(BelaContext *context, int);				// Wrapper for all the functions that need to be called every audio frame
	void setSampleRate(int sampleRate);						// Sets sampleRate_
	void setTempo(int bpm);									// Sets bpm and beatCounter
	void incrementCounter();								// Increments and resets beatCounter_
	int getBeatInterval();									// Tells other classes where the downbeat (tactus) is, and how many samples it contains
	bool getMetronomeState();								// Tells us if the metronome is on(true) or off(false)
	bool isDownBeat();
	void printStatus();
	void readMetronomeButton(BelaContext *context, int);
	void readTempoPot(BelaContext *context, int);
	void resetCounters();
	void changeMetronomeState();
	int getBPM();
	int getBeatCounter();

	// Button handling
	bool buttonPressed(BelaContext *context, int);
	
	// ***Destructor***
	~Metronome();
		
};