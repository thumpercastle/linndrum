 /***** Common.cpp *****/
// #pragma once
#include "Common.h"
#include <unordered_map>
#include <list>

// Cycle through the four toggle sets of drums and percussion instruments and detect button presses.
void handleDrumKit(BelaContext *context, int n, Button (&DrumButtons)[4], Button (&ToggleButton), SingleDrum (&gDrumKit)[16], Scheduler (&gScheduler), Metronome (&gMetronome)) {
	// Wrap state machine
	if(ToggleButton.buttonPressed(context, n)) {
		gDrumKitToggleState++;
		if(gDrumKitToggleState > ToggleState4) {
			gDrumKitToggleState = ToggleState1;
		}	
	}
	switch(gDrumKitToggleState) {
		// If on the first bank of drums
		case ToggleState1: {
			// Iterate through the buttons
			for(int i {0}; i < NUMBER_OF_DRUMS_PER_TOGGLE; i++) {
				// Check for button presses
				if(DrumButtons[i].buttonPressed(context, n)) {
					// Trigger the drum sound
					gDrumKit[i].triggerDrum();
					// If we are recording
					if(gScheduler.getRecordingState()) {
						// Quantise the onset
						int quantisedFrame = gScheduler.quantiseOnset(gMetronome.getBeatCounter());
						// Write event to buffers
						gScheduler.writeDrumEventToBuffer(quantisedFrame, i);
						gScheduler.writeDrumEventToUndoBuffer(quantisedFrame, i);
					}
				}
			}
			break;
		}
		// Drum bank 2
		case ToggleState2: {
			int lowerIdx = 4;
			int upperIdx = 8;
			for(int i {lowerIdx}; i < upperIdx; i++) {
				if(DrumButtons[i - lowerIdx].buttonPressed(context, n)) {
					gDrumKit[i].triggerDrum();
					if(gScheduler.getRecordingState()) {
						int quantisedFrame = gScheduler.quantiseOnset(gMetronome.getBeatCounter());
						gScheduler.writeDrumEventToBuffer(quantisedFrame, i);
						gScheduler.writeDrumEventToUndoBuffer(quantisedFrame, i);
					}
				}
			}
			break;
		}
		// Drum bank 3
		case ToggleState3: {
			int lowerIdx = 8;
			int upperIdx = 12;
			for(int i {lowerIdx}; i < upperIdx; i++) {
				if(DrumButtons[i - lowerIdx].buttonPressed(context, n)) {
					gDrumKit[i].triggerDrum();
					if(gScheduler.getRecordingState()) {
						int quantisedFrame = gScheduler.quantiseOnset(gMetronome.getBeatCounter());
						gScheduler.writeDrumEventToBuffer(quantisedFrame, i);
						gScheduler.writeDrumEventToUndoBuffer(quantisedFrame, i);
					}
				}
			}
			break;
		}
		// Drum bank 4
		case ToggleState4: {
			int lowerIdx = 12;
			int upperIdx = 16;
			for(int i {lowerIdx}; i < upperIdx; i++) {
				if(DrumButtons[i - lowerIdx].buttonPressed(context, n)) {
					gDrumKit[i].triggerDrum();
					if(gScheduler.getRecordingState()) {
						int quantisedFrame = gScheduler.quantiseOnset(gMetronome.getBeatCounter());
						gScheduler.writeDrumEventToBuffer(quantisedFrame, i);
						gScheduler.writeDrumEventToUndoBuffer(quantisedFrame, i);
					}
				}
			}
			break;
		}
	}
}