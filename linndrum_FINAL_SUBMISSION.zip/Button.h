/***** Button.h *****/
#pragma once
#include <Bela.h>

class Button
{
private:
	int digitalPin_;
	int debounceCounter_ = 0;
	int debounceInterval_ = 0.10 * 44100;
	int buttonLastStatus_ = HIGH;
	int buttonStatus_ = HIGH;
	bool debouncing_ = false;
	bool buttonPress_ = false;

public:
	// Constructor
	Button(int pin)
	: digitalPin_{pin} {
	}
	
	// Read on/off button
	bool buttonPressed(BelaContext *context, int n) {
		buttonLastStatus_ = buttonStatus_;
		buttonStatus_ = digitalRead(context, n, digitalPin_);
		// Button press: Turn on or off metronome
		if(buttonStatus_ == LOW && buttonLastStatus_ == HIGH && debounceCounter_ == 0) {
			debouncing_ = true;
			buttonPress_ = true;
			debounceCounter_ = debounceInterval_;
			buttonLastStatus_ = LOW;
			rt_printf("Button pressed.\n");
			return true;
		}
		// Button release
		else if(buttonStatus_ == HIGH && buttonLastStatus_ == LOW) {
			buttonLastStatus_ = HIGH;
			return false;
		}
		// Debounce
		if(debouncing_ == true && debounceCounter_ != 0) {
			--debounceCounter_;
			if(debounceCounter_ == 0) {
				debouncing_ = false;
			}
			return false;
		}
		else {
			return false;
		}
	}
};