/***** SingleDrum.h *****/
#pragma once
#include <Bela.h>
#include <cmath>
#include <vector>
#include <libraries/AudioFile/AudioFile.h>

#define NUMBER_OF_READ_POINTERS_PER_DRUM 16

class SingleDrum
{
private:
	// Left channel signal
	std::vector<float> left_;
	// Right channel signal
	std::vector<float> right_;
	// Constant ints
	int bufferLength_;
	// Read pointers
	int readPointers_[NUMBER_OF_READ_POINTERS_PER_DRUM] {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
	
public:
	// No-args constructors
	SingleDrum();
	// Constructor with 2D vector as argument
	SingleDrum(std::string);
	// Copy constructor
	SingleDrum(std::vector<std::vector<float> > const&);
	// Find a read pointer not in use and set it to 0
	void triggerDrum();
	// Output the current frame and move read pointer if the read pointer is already in use
	float nextLeftOutput();
	float nextRightOutput();
	void assignSample(std::vector<std::vector<float> > const&);
};